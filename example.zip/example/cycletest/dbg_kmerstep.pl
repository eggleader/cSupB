use strict;
#my$times = $ARGV[0];
my$kmer = $ARGV[0];
#print "repeat times: $times\tkmer\t$kmer\n";
#my$kmer = 20;
#my$minkmer = 20;
my$minkmer = $kmer;
my$step = 2;
while($kmer >= $minkmer){
	qx(mkdir kmc_temp);
	qx(ls -1 --color=no *.fasta|xargs -l -i kmc -ci0 -fm -k$kmer -cs300 {} {}_kmc kmc_temp);
	qx(ls -1 --color=no *.fasta|xargs -l -i kmc_tools sort {}_kmc {}_kmc_sorted_kmc.kmc);
	qx(ls -1 --color=no *.fasta|xargs -l -i echo "{}_kmc_sorted_kmc.kmc" >primates_mtDNAs_kmc_list);
	qx(cosmo-build -d primates_mtDNAs_kmc_list>cosmo-build.stdout 2>&1);
	open(IN,"cosmo-build.stdout") or die("can't find cosmo-build.stdout");
	my$setbits;
	my$totalbits;
	foreach my $line(<IN>){
		chomp($line);
		if($line =~ /Set bits : (\d+)/){
			$setbits = $1;
		}
		if($line =~ /total bits : (\d+)/){
			$totalbits = $1;
			last;
		}
	}
	print "$totalbits\t$setbits\n";
	qx(pack-color primates_mtDNAs_kmc_list.colors 12 $totalbits $setbits >pack-color.stdout 2>&1);
	qx(cosmo-cSupB primates_mtDNAs_kmc_list.dbg primates_mtDNAs_kmc_list.colors.sd_vector >log.txt );
	my$result = "k"."$kmer";
	$kmer -= $step;
	qx(rm -rf kmc_temp);
	qx(mkdir $result);
	qx(mv *.txt $result);
	qx(mv pack-color.stdout $result);
    qx(mv cosmo-build.stdout $result);
    qx(mv primates_mt* $result);
	qx(mv *.fasta_kmc* $result);
	qx(mv stxxl* $result);
	qx(cp *fasta $result);
}

