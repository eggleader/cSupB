#!/usr/bin/perl
use strict;
use warnings;
#the statistics of our node-based detection method should be consisted with cSupB_topo.txt
#the result may have deviations because of the ins/indel statistics method 
open(IN,"myvar.txt") or die "can't find file\n";
my%pos2var;
#my@varcount = (0,0,0,0);
my%varnum;
my$skip = 1;
foreach my$line(<IN>){
	if($skip == 1){
		$skip++;
		next;
	}
	chomp$line;
	my@info = split(/\t/,$line);
	my$refpos = $info[0];
	my$varstr = $info[3];
	#my$vartype = abs($info[4]);
	my$vartype = $info[4];
	if($vartype == -7){
#		print "$line\n";
	}
#	if($info[4]<0){
#		$vartype++;
#	}
#	print "$refpos\t$varstr\t$vartype\n";
	my@vars = split(/:/,$varstr);
	my$maxlen = 1;
	my$len = @vars;
	for(my$i = 0;$i < $len;$i++){
		if(length($vars[$i])>$maxlen){
			$maxlen = length($vars[$i]);
		}
	}
	for(my$i = 0;$i < $maxlen;$i++){
		if(exists($pos2var{$refpos+$i})){
			if(abs($vartype) > abs($pos2var{$refpos+$i})){
				$pos2var{$refpos+$i} = $vartype;
				if(exists($varnum{$vartype})){
					$varnum{$vartype}++;
				}else{
					$varnum{$vartype} = 1;
				}
			#	$varcount[$vartype-1]++;
			#	$varcount[$pos2var{$refpos+$i}-1]--;
			}
			elsif(abs($vartype) == abs($pos2var{$refpos+$i})){
				if($vartype < 0 || $pos2var{$refpos+$i} < 0){
					$pos2var{$refpos+$i} = -abs($vartype);
					if(exists($varnum{-abs($vartype)})){
						$varnum{-abs($vartype)}++;
					}else{
						$varnum{-abs($vartype)} = 1;
					}
					
				}
			}
		}else{
			$pos2var{$refpos+$i} = $vartype;
#			$varcount[$vartype-1]++;
			if(exists($varnum{$vartype})){
				$varnum{$vartype}++;
			}else{
				$varnum{$vartype} = 1;
			}
		}
	}
}
#print "myvar.txt varcount:@varcount\n";
foreach my$key(keys %varnum){
	my$value = $varnum{$key};
	print "$key:$value\n";

}
