#!/usr/bin/perl
### usage: simimulate the sequences 
use strict;
use warnings;
#my$input_snp = $ARGV[0];
my$input_snp = 100;
open(IN,"NC_012920.fa") or die "can't find reffile\n";
open(OUT1,">simvar.txt");
open(OUT2,">simseq.fa");
my@seqs = <IN>;
my$ref = $seqs[0];
chomp$ref;
my$reflen = length($ref);
print"reflen:$reflen\n";
my$seed = 1;
my($snp,$ins,$del)=($input_snp,10,10);
my$totalvar = $snp+$ins+$del;
my($maxins,$maxdel)=(2,2);
my$samplenum = 10-1;
my(@vartyperand,@refposrand);
my$kmer = 70;
my%base = (1=>'A',2=>'C',3=>'G',4=>'T',0=>"-");

for(my$i = 0;$i < $totalvar;$i++){
	my$tmpvar = int(rand($totalvar));
	push(@vartyperand,$tmpvar);
	my$tmppos = int(rand($reflen-$kmer-$kmer))+$kmer;
	push(@refposrand,$tmppos);
}
#print "$vartyperand[0]\t$vartyperand[$totalvar-1]\n";
#print "$refposrand[0]\t$refposrand[$totalvar-1]\n";
my@sortrefposrand = sort{$a<=>$b}@refposrand; 
print "$sortrefposrand[0]\t$sortrefposrand[$totalvar-1]\n";
my%count;
my @uniq_sortrefposrand = grep { ++$count{ $_ } < 2; } @sortrefposrand;
my$uniq_totalvar = @uniq_sortrefposrand;

print OUT1 "pos\tref\talt\ttype\tgaplen\taltcount\n";
#my$emptystr = "";
my@simseqs;
#my@simseqs = $samplenum*"TG";
for(my$i = 0;$i < $samplenum;$i++){
	push @simseqs,$ref;
	#push @simseqs,$emptystr;
}
#$simseqs[$samplenum-1] = $ref;

for(my$i = $uniq_totalvar - 1;$i >= 0;$i--){
	my$pos = $uniq_sortrefposrand[$i];
	if($pos < $kmer || $pos > $reflen - $kmer){
		print "pos:$pos\n";
	}
	my$var = $vartyperand[$i];
	my$vartype;
	if($var < $snp){
		$vartype = 1;
	}elsif($var > $snp+$del-1){
		$vartype = 3;
	}else{
		$vartype = 2;
	}
	my$varsampnum = int(rand($samplenum))+1;#[1,sampnum-1]  exclude reference
	my@randsamp;
	for(my $j = 0;$j < $varsampnum;$j++){
		my$tmprandsamp = int(rand($samplenum));
		push(@randsamp,$tmprandsamp);
	}
	my%count1;
	my@sortrandsamp = sort{$a<=>$b}@randsamp;#get variant samples id
	my @uniq_sortrandsamp = grep { ++$count1{ $_ } < 2; } @sortrandsamp;
	my$selectsampnum = @uniq_sortrandsamp;
	if($vartype == 1){
		my$varbase = substr($ref,$pos,1);
		my$refbase = substr($ref,$pos,1);
		my$findvar = 0;
		while($findvar == 0){
			my$baseid = int(rand(3))+1;
			my$tmpbase = $base{$baseid};
			if($tmpbase ne $varbase){
				$varbase = $tmpbase;
				$findvar = 1;
			}
		}
		for(my$sampid = 0;$sampid < $selectsampnum;$sampid++){
			my$varsamp = $uniq_sortrandsamp[$sampid];
		#	print "$pos\t$selectsampnum\t$varsamp\n";
			my$sampseq = $simseqs[$varsamp];
			my$sampseqlen = length($sampseq);
			my$substr1 = substr($sampseq,0,$pos);
			my$substr2 = substr($sampseq,$pos+1,$sampseqlen-$pos-1);
#			print "$pos:$sampseqlen\n";
			my$newseq = "$substr1"."$varbase"."$substr2";
		#	$sortrandsamp[$sampid] = $newseq;
			$simseqs[$varsamp] = $newseq;
		}
		$pos++;
		print OUT1 "$pos\t$refbase\t$varbase\t$vartype\t0\t$selectsampnum\n";
	}elsif($vartype == 2){
		my$gaplen = int(rand($maxdel-1))+1;
		my$refbase = substr($ref,$pos,$gaplen);
		for(my$sampid = 0;$sampid < $selectsampnum;$sampid++){
			my$varsamp = $uniq_sortrandsamp[$sampid];
			my$sampseq = $simseqs[$varsamp];
			my$sampseqlen = length($sampseq);
			my$substr1 = substr($sampseq,0,$pos);
			my$substr2 = substr($sampseq,$pos+$gaplen,$sampseqlen-$pos-$gaplen);
			my$newseq = "$substr1"."$substr2";
			$simseqs[$varsamp] = $newseq;
			#$sortrandsamp[$sampid] = $newseq;
		}
		my$varbase = '-';
		$pos++;
		print OUT1 "$pos\t$refbase\t$varbase\t$vartype\t$gaplen\t$selectsampnum\n";
	}else{
		my$gaplen = int(rand($maxins-1))+1;
		my$insvar;
		for(my$gapid = 0;$gapid < $gaplen;$gapid++){
			my$varid = int(rand(3))+1;
			my$varbase = $base{$varid};
			$insvar .= $varbase;
		}
		for(my$sampid = 0;$sampid < $selectsampnum;$sampid++){
			my$varsamp = $uniq_sortrandsamp[$sampid];
			my$sampseq = $simseqs[$varsamp];
			my$sampseqlen = length($sampseq);
			my$substr1 = substr($sampseq,0,$pos);
			my$substr2 = substr($sampseq,$pos,$sampseqlen-$pos);
			my$newseq = "$substr1"."$insvar"."$substr2";
			$simseqs[$varsamp] = $newseq;
			#$sortrandsamp[$sampid] = $newseq;
			
		}
		my$refbase = substr($ref,$pos,1);
		my$varbase = "$insvar"."$refbase";
		$pos++;
		print OUT1 "$pos\t$refbase\t$varbase\t$vartype\t$gaplen\t$selectsampnum\n";
	}
}


for(my$i = 0;$i < $samplenum;$i++){
	my$id = $i+1;
	my$name = "CMBsim$id";
	my$filename = "$name.fasta";
	#open(OUT3,">tmp/$filename");
	open(OUT3,">$filename");
	print OUT2 ">$name\n$simseqs[$i]\n";
	print OUT3 ">$name\n$simseqs[$i]\n";
	close OUT3;
}
close OUT2;
close OUT1;
